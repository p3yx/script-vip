from kyt import *
import subprocess
import time
import datetime as DT

@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    await event.respond("Pilih opsi:", buttons=[
        [Button.inline(" TRIAL SSH ","trial-ssh"),
         Button.inline(" CREATE SSH ","create-ssh")],
        [Button.inline(" LOGIN SSH ","login-ssh"),
         Button.inline(" DELETE SSH ","delete-ssh")],
        [Button.inline(" SHOW All USER ","show-ssh"),
         Button.inline(" CHANGE IP ","limit-ssh")],
        [Button.inline(" LOCK SSH ","lock-ssh"),
         Button.inline(" UNLOCK SSH ","unlock-ssh")],
        [Button.inline("‹ Main Menu ›","menu")]
    ])

@bot.on(events.CallbackQuery(data=b'lock-ssh'))
async def lock_ssh(event):
    await event.respond("Masukkan username SSH yang ingin di-lock:", buttons=[[Button.inline("‹ Back to Menu ›", "menu")]])

    # Menunggu input username
    username_event = await bot.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
    username = username_event.raw_text.strip()

    # Perintah untuk mengunci akun SSH
    cmd = f"usermod -L {username}"
    try:
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"Akun SSH `{username}` telah berhasil di-lock.", buttons=[[Button.inline("‹ Back to Menu ›", "menu")]])
    except subprocess.CalledProcessError:
        await event.respond(f"Gagal mengunci akun `{username}`. Pastikan username valid.", buttons=[[Button.inline("‹ Back to Menu ›", "menu")]])

@bot.on(events.CallbackQuery(data=b'unlock-ssh'))
async def unlock_ssh(event):
    await event.respond("Masukkan username SSH yang ingin di-unlock:", buttons=[[Button.inline("‹ Back to Menu ›", "menu")]])

    # Menunggu input username
    username_event = await bot.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
    username = username_event.raw_text.strip()

    # Perintah untuk membuka kunci akun SSH
    cmd = f"usermod -U {username}"
    try:
        subprocess.check_output(cmd, shell=True)
        await event.respond(f"Akun SSH `{username}` telah berhasil di-unlock.", buttons=[[Button.inline("‹ Back to Menu ›", "menu")]])
    except subprocess.CalledProcessError:
        await event.respond(f"Gagal membuka kunci akun `{username}`. Pastikan username valid.", buttons=[[Button.inline("‹ Back to Menu ›", "menu")]])

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    async def create_ssh_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        async with bot.conversation(chat) as pw:
            await event.respond("**Password:**")
            pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text
        async with bot.conversation(chat) as exp:
            await event.respond("**Choose Expiry Day**",buttons=[
                [Button.inline(" 7 Days ","7"),
                Button.inline(" 15 Days ","15")],
                [Button.inline(" 30 Days ","30"),
                Button.inline(" 60 Days ","60")]])
            exp = exp.wait_event(events.CallbackQuery)
            exp = (await exp).data.decode("ascii")
        await event.edit("Processing..")
        await event.edit("Processing...")
        time.sleep(2)
        await event.edit("`Processing Crate Premium Account`")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(0)
        await event.edit("`Processing... 100%\n█████████████████████████ `")
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd,shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
◇━━━━━━━━━━━━━━━━━━━━━━━◇
             SSH OVPN ACCOUNT 
◇━━━━━━━━━━━━━━━━━━━━━━━◇
» Username : `{user.strip()}`
» Password : `{pw.strip()}`
» Host : `{DOMAIN}`
◇━━━━━━━━━━━━━━━━━━━━━━━◇
            PORT INFORMATION 
◇━━━━━━━━━━━━━━━━━━━━━━━◇
» Port OpenSSH   : `443, 80, 22`
» Port DNS   : `443, 53 ,22`
» Port Dropbear   : `443, 109`
» Port Dropbear WS   : `443, 109`
» Port SSH WS   : `80, 8080, 8081-9999`
» Port SSH SSL WS   : `443`
» Port SSL/TLS   : `222-1000`
» Port OVPN WS SSL   : `443`
» Port OVPN SSL   : `443`
» Port OVPN TCP   : `443, 1194`
» Port OVPN UDP   : `1-65535`
» Proxy Squid   : `3128`
» BadVPN UDP   : `7100, 7300, 7300`
◇━━━━━━━━━━━━━━━━━━━━━━━◇
» UDP CUSTOM :
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
◇━━━━━━━━━━━━━━━━━━━━━━━◇
» SSH WS HTTP CUSTOM :
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
◇━━━━━━━━━━━━━━━━━━━━━━━◇
» Payload WSS  : `GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
◇━━━━━━━━━━━━━━━━━━━━━━━◇
» OpenVPN WS SSL  : `https://{DOMAIN}:81/ws-ssl.ovpn`
» OpenVPN SSL  : `https://{DOMAIN}:81/ssl.ovpn`
» OpenVPN TCP  : `https://{DOMAIN}:81/tcp.ovpn`
» OpenVPN UDP  : `https://{DOMAIN}:81/udp.ovpn`
◇━━━━━━━━━━━━━━━━━━━━━━━◇
» Save Link Account: `https://{DOMAIN}:81/ssh-{user.strip()}.txt`
» Expired Until: `{later}`
**» 🤖@peyyx**
"""
            await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_ssh_(event)
    else:
        await event.answer("Akses Ditolak",alert=True)