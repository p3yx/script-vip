from telethon import TelegramClient, events, Button
import subprocess
import time

api_id = 123456  # Ganti dengan API ID kamu
api_hash = 'your_api_hash'  # Ganti dengan API Hash kamu
bot_token = 'your_bot_token'  # Ganti dengan token bot kamu

bot = TelegramClient('bot', api_id, api_hash).start(bot_token=bot_token)

def valid(userid):
    authorized_users = ["123456789", "987654321"]
    return "true" if userid in authorized_users else "false"

def get_server_info():
    # Dummy data untuk contoh, bisa diganti dengan data yang sesuai
    z = {
        "isp": "IndoInternet",
        "country": "Indonesia"
    }
    domain = "example.com"  # Ganti dengan domain yang sesuai
    return z, domain

def get_total_ssh_accounts():
    try:
        result = subprocess.check_output("awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd", shell=True).decode()
        return len(result.splitlines())
    except:
        return 0

@bot.on(events.NewMessage(pattern="/ssh"))
async def ssh_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        total_accounts = get_total_ssh_accounts()
        inline = [
            [Button.inline(" TRIAL SSH ","trial-ssh"),
             Button.inline(" CREATE SSH ","create-ssh")],
            [Button.inline(" LOGIN SSH ","login-ssh"),
             Button.inline(" DELETE SSH ","delete-ssh")],
            [Button.inline(" SHOW All USER ","show-ssh"),
             Button.inline(" CHANGE IP ","limit-ssh")],
            [Button.inline(" LOCK SSH ","lock-ssh"),
             Button.inline(" UNLOCK SSH ","unlock-ssh")],
            [Button.inline(" STATUS AKUN ","status-ssh")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        await event.respond(f"**💥SSH OVPN MANAGER 💥**\n✧◇───────────────────◇✧\n"
                            f"** ✨» Service :** `SSH OVPN`\n"
                            f"** ✨» Hostname/IP :** `example.com`\n"  # Ganti dengan variabel domain sesuai
                            f"** ✨» ISP :** `IndoInternet`\n"
                            f"** ✨» Country :** `Indonesia`\n"
                            f"** ✨» Total Akun :** `{total_accounts}`\n"
                            f"** 🤖» @peyyx**\n"
                            f"✧◇───────────────────◇✧", buttons=inline)
    else:
        await event.respond("Akses Ditolak.")

# Trial SSH
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    z, domain = get_server_info()
    total_accounts = get_total_ssh_accounts()
    await event.respond(f"**💥SSH OVPN MANAGER 💥**\n✧◇───────────────────◇✧\n"
                        f"** ✨» Service :** `SSH OVPN`\n"
                        f"** ✨» Hostname/IP :** `{domain}`\n"
                        f"** ✨» ISP :** `{z['isp']}`\n"
                        f"** ✨» Country :** `{z['country']}`\n"
                        f"** ✨» Total Akun :** `{total_accounts}`\n"
                        f"** 🤖» @peyyx**\n"
                        f"✧◇───────────────────◇✧\n"
                        "Anda telah memilih *Trial SSH*. Trial SSH adalah akun yang dapat digunakan untuk mengakses server selama 1 hari. "
                        "Setelah masa aktifnya habis, akun ini akan otomatis kadaluarsa dan tidak bisa digunakan lagi.\n\n")
    try:
        result = subprocess.check_output("useradd -e `date -d '1 day' +%Y-%m-%d` -s /bin/false trialuser && echo 'trialuser:123' | chpasswd", shell=True)
        await event.respond(f"Trial SSH berhasil dibuat:\nUsername: `trialuser`\nPassword: `123`\nMasa aktif: 1 hari")
    except:
        await event.respond("Gagal membuat trial akun SSH.")

# Create SSH
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.respond("Akses ditolak.")
    
    async with bot.conversation(event.chat_id) as conv:
        await conv.send_message("Masukkan Username:")
        username = (await conv.get_response()).text
        await conv.send_message("Masukkan Password:")
        password = (await conv.get_response()).text
        await conv.send_message("Masukkan Hari Aktif:")
        days = (await conv.get_response()).text

        await conv.send_message(f"Proses pembuatan akun SSH dimulai.\nMenyiapkan username `{username}` dengan password `{password}` selama {days} hari.\nMohon tunggu...")
        
        try:
            cmd = f"useradd -e `date -d '{days} days' +%Y-%m-%d` -s /bin/false {username} && echo '{username}:{password}' | chpasswd"
            subprocess.run(cmd, shell=True, check=True)
            await conv.send_message(f"Akun SSH berhasil dibuat:\nUsername: `{username}`\nPassword: `{password}`\nAktif: {days} hari")
        except:
            await conv.send_message("Gagal membuat akun.")

# Show all user
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    total_accounts = get_total_ssh_accounts()
    await event.respond(f"**💥SSH OVPN MANAGER 💥**\n✧◇───────────────────◇✧\n"
                        f"** ✨» Total Akun SSH :** `{total_accounts}`\n"
                        f"** 🤖» @peyyx**\n"
                        f"✧◇───────────────────◇✧")
    try:
        result = subprocess.check_output("awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd", shell=True).decode()
        await event.respond("**Daftar Akun SSH:**\n" + result)
    except:
        await event.respond("Gagal mengambil daftar user.")

# Other callback query handlers (limit-ssh, lock-ssh, unlock-ssh, etc.) remain the same

# Bot jalan
print("Bot Telegram SSH aktif...")
bot.run_until_disconnected()