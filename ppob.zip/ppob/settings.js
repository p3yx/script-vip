/*

  !- Credits By PEYX
  https://wa.me/6283151636921
  
*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

//~~~~~~~~~~~ Settings Bot ~~~~~~~~~~~//
global.owner = '6283151636921'
global.versi = "3.0.0"
global.namaOwner = "peyx"
global.packname = 'px'
global.botname = 'px'
global.botname2 = 'PX BOTZ'

//~~~~~~~~~~~ Settings Link ~~~~~~~~~~//
global.linkOwner = "https://wa.me/6283151636921"
global.linkWebsite = "https://whatsapp.com/channel/0029Vaj7rCF2phHIcXbV3v1N"
global.linkGrup = "https://chat.whatsapp.com/HNACwQRxuoY7rVg6q12d4m"

//~~~~~~~~~~~ Settings Jeda ~~~~~~~~~~//
global.delayJpm = 3500
global.delayPushkontak = 6000

//~~~~~~~~~~ Settings Saluran ~~~~~~~~~//
global.linkSaluran = "https://whatsapp.com/channel/0029Vaj7rCF2phHIcXbV3v1N"
global.idSaluran = "120363335989645846@newsletter"
global.namaSaluran = "PX STORE"

//~~~~~~~~~ Settings Orderkuota ~~~~~~~~//
global.pinH2H = "5555"
global.passwordH2H = "duriduri34"
global.merchantIdOrderKuota = "OK1412639"
global.apiOrderKuota = "727329817453713371412639OKCT3FCBBE1DEF8C9F33A419C2246A811328"
global.qrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214737458216203040303UMI51440014ID.CO.QRIS.WWW0215ID20233008504920303UMI5204541153033605802ID5919MRZ STORE OK14126396008SUKABUMI61054311162070703A0163043479"


//~~~~~~~~~~ Settings Apikey ~~~~~~~~~~//
global.apiDigitalOcean = "-"
global.apiSimpleBot = "new2025"

//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "083151636921"
global.ovo = "Tidak Tersedia"
global.gopay = "087744622208"

//~~~~~~~~~~ Settings Image ~~~~~~~~~~//
global.image = {
menu: "https://files.catbox.moe/gsn3e1.jpg", 
reply: "https://files.catbox.moe/gsn3e1.jpg", 
logo: "https://files.catbox.moe/gsn3e1.jpg", 
qris: "https://files.catbox.moe/bb3hfw.jpg"
}

//~~~~~ Settings Api Panel Buy Panel ~~~~~//
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "-"
global.apikey = "ptla_X6Yqa4606ob7nX4MXluBDHCAhBX88O8aNVFJD1GwsH2" //ptla
global.capikey = "ptlc_czMmOrpF79X98JrpS3oxFouhbiVdip1HYmTqlCXbMKQ" //ptlc

//~~~~~~~ Settings Api Subdomain ~~~~~~~//
global.subdomain = {
"xyzpanel.biz.id": {
"zone": "c93b80618a93cad3230b9404594b9496", 
"apitoken": "luOcKcR4vO9IWeBZYuFPrIH_YwgfVz_zM7qno_Jv"
}, 
"xyzpanel.my.id": {
"zone": "80b008551652777183fc223cbda97423", 
"apitoken": "anBhM0iiVJIbONiA2DhjPYB-nz24BvjPJuO5I3Oi"
}, 
"xyzhiraa.biz.id": {
"zone": "7a2ddd167601af098839df7b44cb507b", 
"apitoken": "ebxjF1BYlWi5xCZWCfzrU5ZiXT9-iAeWNvRQhkgr"
}, 
"hirapanel.my.id": {
"zone": "39d3b9c457f95a4d84a9c64a1cfcc12b", 
"apitoken": "COr7gidc5F97acH3Ssb6hHXtFrlT3EmVSCEav9Zf"
}, 
"hiracans.my.id": {
"zone": "f11806886242e30398861f26bba8d920", 
"apitoken": "rW13adieaMxvjPxEuaMMim3YxCegntwXHWbvUg8e"
}, 
"privatehira.biz.id": {
"zone": "e4baad1a6acd48d575d0cb7a43a3ae53", 
"apitoken": "U5IXHD7pMY2N_yH0Ld6X9Yi0qaZyZD-9E9UdYpWX"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "ImdyjF7XVU7ObDbdCr7LwSUZ4eDQJ-QozAbUIWoF"
}
}

//~~~~~~~~~~ Settings Message ~~~~~~~~//
global.mess = {
	owner: "*[ Akses Ditolak ]*\nFitur ini hanya untuk owner bot!",
	admin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk admin grup!",
	botAdmin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam grup!",
	private: "*[ Akses Ditolak ]*\nFitur ini hanya untuk dalam private chat!",
	prem: "*[ Akses Ditolak ]*\nFitur ini hanya untuk user premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})